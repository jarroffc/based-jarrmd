  ** JarrMD Base (cjs) **
    └• Copyright (c) by Jarr
    └• t.me/jarroffc2
    
  **Sumber share:** https://whatsapp.com/channel/0029VbAbEkb5Ejy7jjjG7p3H

  **JANGAN DI HAPUS HARGAIN!!**
  
  _Base bot WhatsApp dengan type commodJs (cjs) simpel support on lama tanpa bad sesions, silahkan jalankan script menggunakan panel Peterodactyl dengan node.js versi 20+_
  
  ## pemula jir jangan bully plis 
  
  **Note**
  `Base ini gratis woi jangan di juwal ygy🤓`