const fs = require("fs");
const path = require("path");

const handler = async (m, sock, { isOwner, text, command, reply, totalFitur, totalPlugin, isBan }) => {
  try {
    if (isBan) return await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    if (!isOwner) return reply(mess.own);

    const baseDir = path.join(__dirname, "../../plugins");

    if (!text.endsWith(".js")) return reply(`Contoh: *.${command}* command/menu.js\n\nKetik: *.listplugin* untuk lihat file plugins`);

    const targetPath = path.join(baseDir, text.trim());
    if (!fs.existsSync(targetPath)) return reply("Plugin tidak ditemukan.");

    const fileContent = fs.readFileSync(targetPath, "utf8");
    return reply(fileContent);
  } catch (err) {
    console.error(err);
    return reply("Terjadi kesalahan saat membaca plugin.");
  }
};

handler.command = ["getp", "gp", "getplugin", "getplugins"];
module.exports = handler;