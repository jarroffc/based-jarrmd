
const handler = async (m, sock) => {
let tq =`*Thanks To*

- Allah SWT
- Nabi Muhammad SAW
- Orang Tua Saya
- Keluarga Saya
- Developer (Jarr)
- Para pembeli script 
- All creator script`
m.reply(tq)
}
handler.command = [
 "tqto"
] 
module.exports = handler