const handler = async (m, sock, { reply }) => {
  try {
    const userJid = m.sender;
    const userNumber = userJid.split("@")[0];

    let ppUrl;
    try {
      ppUrl = await sock.profilePictureUrl(userJid, "image");
    } catch {
      ppUrl = "https://telegra.ph/file/265c672094dfa87caea19.jpg"; 
    }

    const contact = await sock.onWhatsApp(userJid);
    const pushName = m.pushName || (contact?.notify || "Tidak diketahui");

    await sock.sendMessage(m.chat, {
      image: { url: ppUrl },
      caption: `*—About You 🌛*
      
- 👤 *Nama:* ${pushName}
- 📞 *Nomor:* wa.me/${userNumber}
- 🤖 *Status:* ${isOwner ? "owner" : isSewa ? "premium user" : "free user"}

_~Tetap hidup walau ga berguna yaa ∆_∆` 
    }, { quoted: m });
  } catch (err) {
    console.error("Error profile:", err);
    await m.reply("Terjadi kesalahan saat mengambil profil kamu.");
  }
};

handler.command = ["profile","pp"];
module.exports = handler;