const handler = async (m, sock, { command, reply, totalFitur, getPluginStats, text }) => {

const info = getPluginStats();

const jarrdev =`*Total Features*
> Total Fitur Case : ${totalFitur}
> Total file : (${info.totalFiles}) plugin 
> Folder category : (${info.totalCategory}) folders`
reply(jarrdev)
}

handler.command = ["totalfitur","total"]
module.exports = handler