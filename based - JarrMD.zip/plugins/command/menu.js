const handler = async (m, sock, { isOwner, text, subCmd, reply, example, totalFitur, fakeMsg, getPluginStats }) => {

let teks = `Hai @${m.sender.split("@")[0]}

\`This script info:\`
> name : ${global.namaBot}
> developer : ${global.namaOwner}
> version : ${global.versiBot}
> type : case x plugins (cjs)

_—owner menu_
 └• .addplugin 
 └• .delplugin 
 └• .listplugin
 └• .getplugin 
 └• .getcase
 └• .bot-off
 └• .bot-on

_—info menu_
 └• .ping
 └• .owner
 └• .totalfitur
 └• .tqto
 └• .bot

_—main menu_
 └• .sticker
 └• .tourl`

sock.sendMessage(m.chat, { 
    text: teks, 
    mentions: [m.sender],
}, { quoted: fakeMsg });
}

handler.command = ["menu"];
module.exports = handler;