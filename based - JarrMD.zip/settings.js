/*
  ** Base cjs case × plugin simpel 
  ** Copyright (c) by Jarr
  
  Join Bang
  ** https://whatsapp.com/channel/0029VbAbEkb5Ejy7jjjG7p3H

  Jangan hapus plis tambah aja nama mu
  
*/

const chalk = require("chalk");
const fs = require("fs");

// ~~ setting pairing kode ~~
global.pairingCode = "JARRXCDE"

// ~~ setting bot ~~
global.owner = "6285876485652"
global.owner2 = [
"6285876485652", "6285700158613"
] //buat fitur bot on/off

global.namaOwner = "Jarr"
global.namaBot = "Base JarrMD"
global.versiBot = "1.0"

// ~~ setting foto ~~
global.fotoOwner = "https://files.catbox.moe/v0n8z8.jpg"

// ~~ setting saluran ~~
global.idChannel = "120363253324828163@newsletter"
global.namaChannel = "jarr - xcde"


global.mess = {
 owner: "*Maaf fitur ini hanya dapat digunakan pemilik bot!*",
 admin: "*Maaf fitur ini hanya dapat digunakan oleh admin grup!*",
 botAdmin: "*Maaf sepertinya bot harus menjadi admin grup ini!*",
 group: "*Maaf fitur ini hanya dapat digunakan di dalam group chat!*"
}

let file = require.resolve(__filename);
fs.watchFile(file, () => {
    fs.unwatchFile(file);
    console.log(chalk.red(">> Update File:"), chalk.black.bgWhite(__filename));
    delete require.cache[file];
    require(file);
});